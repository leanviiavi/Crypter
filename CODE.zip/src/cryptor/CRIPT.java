package cryptor;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class CRIPT {
	
	public String Cript(String FileName, String KEY_) throws Exception{
		
		FileInputStream fis = new FileInputStream (FileName);
		
		String newPath = "workspace/file/crypter/data/";
		
		String mainFile = "";
		
		for (int i=FileName.length()-1; i>-1; i--){
			if (FileName.charAt(i)!='\\'){
				mainFile += FileName.charAt(i);
			}else break;
		}
		String reverse = "";
		
		for (int i=mainFile.length()-1; i>-1; i--){
			if (mainFile.charAt(i)!='\\'){
				reverse += mainFile.charAt(i);
			}else break;
		}
		
		FileOutputStream fos = new FileOutputStream (newPath + "Crypted " + reverse + ".cpd");
		
		byte[] block = new byte[8];
		int i;
		int fun = 0;
		while( (i=fis.read(block)) != -1){
			for (int j=0; j<8; j++){
				for (int g=0;g<2;g++){
					block[j] = (byte) (block[j] + (int)(Byte.parseByte(String.valueOf(KEY_.charAt(fun % KEY_.length()))))%256);
					fun++;
				}
			}
			fos.write(block,0,i);
		}
		
		
		fis.close();
		fos.close();
		return "1";
	}
	
public String Decript(String path, String FileName, String KEY_) throws Exception{

		FileInputStream fis = new FileInputStream (path + FileName);
		int len = FileName.length();
		String name = "";
		for (int i=0; i<len-4; i++){
			name += FileName.charAt(i);
		}
		String pathWithName = "";
		name = name.replace('\\','/');
		for (int i=name.length()-1; i>-1; i--){
			if (name.charAt(i) != '/'){
					pathWithName += name.charAt(i);
			}else{
				break;
			}
		}
		String Path = "\\";
		for (int i=pathWithName.length()-1; i>-1; i--){
			Path += pathWithName.charAt(i);
		}
		pathWithName = path + Path;
		FileOutputStream fos = new FileOutputStream (pathWithName);
		
		byte[] block = new byte[8];
		int i;
		int fun = 0;
		while( (i=fis.read(block)) != -1){
			for (int j=0; j<8; j++){
				for (int g=0;g<2;g++){
					block[j] = (byte) (block[j] - (int)(Byte.parseByte(String.valueOf(KEY_.charAt(fun % KEY_.length()))))%256);
					//block[j] = (byte) (block[j] - Integer.parseInt(KEY_));
					fun++;
				}
			}
			fos.write(block,0,i);
		}
		
		
		fis.close();
		fos.close();
		Runtime rt = Runtime.getRuntime();
		rt.exec(new String[]{"cmd.exe","/c",pathWithName});
		return "1";
	}

}
