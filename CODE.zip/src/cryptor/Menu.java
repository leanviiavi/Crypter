package cryptor;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Window.Type;
import java.awt.Panel;
import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JScrollBar;
import javax.swing.JMenuItem;
import javax.swing.JList;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.awt.List;

import javax.swing.JTextPane;
import javax.swing.JTextField;

import java.awt.Toolkit;

public class Menu extends JFrame {

	private JPanel contentPane;
	private Panel workspace = new Panel();
	private List list = new List();
	private String WorkspacePath = "";
	private JTextPane textPane = new JTextPane();
	private JTextField key;
	private String files[];
	public static String fileWith = "";
	private static Menu frame;
	
	private int countOfClick = 0;
	private JTextField textField;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		fileWith = Arrays.toString(args);
		System.out.println("file = "+fileWith);
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\leanviiavi\\Desktop\\\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F\\icon.ico"));
		setResizable(false);
		setTitle("Crypter v.0.0.1");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 701, 401);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		boolean isLicense = false;
		if (getValidation()==2){
			textPane.setText("������ �������� ��������!");
		}
		if (getValidation()==1){
			isLicense = true;
		}
		if (getValidation()==0){
			isLicense = false;
		}
		
		Panel controlPanel = new Panel();
		controlPanel.setBounds(0, 0, 148, 160);
		contentPane.add(controlPanel);
		controlPanel.setLayout(null);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.DARK_GRAY);
		panel_1.setBounds(0, 0, 300, 18);
		controlPanel.add(panel_1);
		panel_1.setLayout(null);
		
		final JLabel label = new JLabel("\u041F\u0430\u043D\u0435\u043B\u044C \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F");
		label.setFont(new Font("Verdana", Font.PLAIN, 11));
		label.setForeground(Color.WHITE);
		label.setBounds(10, 0, 145, 14);
		panel_1.add(label);
		
		Panel panel_2 = new Panel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(0, 21, 148, 139);
		controlPanel.add(panel_2);
		panel_2.setLayout(null);
		
		
		
		final JButton button_1 = new JButton("\u041F\u043E\u043C\u043E\u0449\u043D\u0438\u043A");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String fileName_text = "settings/Readme .txt";
				String fileName_word = "settings/Readme .docx";
				
				try{
					Runtime rt = Runtime.getRuntime();
					rt.exec(new String[]{"cmd.exe","/c",fileName_word});
				}catch(Exception e){
					try {
						Runtime rt = Runtime.getRuntime();
						rt.exec(new String[]{"cmd.exe","/c",fileName_text});
					} catch (IOException e1) {
						textPane.setText("����������� ����� ���������!");
					}
						
				}
				
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(Color.GRAY);
		button_1.setBounds(10, 55, 128, 33);
		panel_2.add(button_1);
		
		final JButton button_2 = new JButton("\u041F\u0440\u043E\u0447\u0435\u0435");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String fileName_text = "settings/Version .txt";
				String fileName_word = "settings/Version .docx";
				
				try{
					Runtime rt = Runtime.getRuntime();
					rt.exec(new String[]{"cmd.exe","/c",fileName_word});
				}catch(Exception e){
					try {
						Runtime rt = Runtime.getRuntime();
						rt.exec(new String[]{"cmd.exe","/c",fileName_text});
					} catch (IOException e1) {
						textPane.setText("����������� ����� ���������!");
					}
						
				}
				
			}
		});
		button_2.setForeground(Color.WHITE);
		button_2.setBackground(Color.GRAY);
		button_2.setBounds(10, 99, 128, 33);
		panel_2.add(button_2);
		
		Panel filesPanel = new Panel();
		filesPanel.setLayout(null);
		filesPanel.setBounds(0, 160, 148, 212);
		contentPane.add(filesPanel);
		
		Panel panel_4 = new Panel();
		panel_4.setLayout(null);
		panel_4.setBackground(Color.DARK_GRAY);
		panel_4.setBounds(0, 0, 300, 18);
		filesPanel.add(panel_4);
		
		final JLabel label_1 = new JLabel("\u0420\u0430\u0431\u043E\u0442\u0430 \u0441 \u0434\u0430\u043D\u043D\u044B\u043C\u0438");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Verdana", Font.PLAIN, 11));
		label_1.setBounds(20, 0, 135, 14);
		panel_4.add(label_1);
		
		Panel panel_5 = new Panel();
		panel_5.setLayout(null);
		panel_5.setBackground(Color.LIGHT_GRAY);
		panel_5.setBounds(0, 21, 148, 192);
		filesPanel.add(panel_5);
		
		final JButton button_3 = new JButton("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String key_ = key.getText();
				
				boolean isValid = false;
				
				for (int i=0; i<key_.length(); i++){
					if (key_.charAt(i) >= '0' && key_.charAt(i) <= '9'){
						isValid = true;
					}else{
						isValid = false;
						break;
					}
				}
				
					if (key_.length() > 0 && key_.length() < 512){
						if (isValid){
						//��������� ����
						String FileName = showFileDialog();
						
						try{
							CRIPT cr = new CRIPT();
							cr.Cript(FileName, key_);
							textPane.setText("���� ������� ��������!");
						}catch(Exception e){
							textPane.setText("������ �������� �����!");
						}
					}else{
						textPane.setText("�� ����� ���� ������!");
					}
				}else{
					textPane.setText("�� ������ ���� ������������ ��� �����!");
				}
				
				
			}
		});
		button_3.setForeground(Color.WHITE);
		button_3.setBackground(Color.GRAY);
		button_3.setBounds(10, 11, 128, 33);
		panel_5.add(button_3);
		
		final JButton button_4 = new JButton("\u0421\u043F\u0438\u0441\u043E\u043A");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				//�������� 1 - ����� ������� ������ �� ������� ������
				list.removeAll();
				 final Font font = new Font("Verdana", Font.PLAIN, 25);
				 WorkspacePath = "workspace/file/crypter/data/";
				 
				 File file = new File(WorkspacePath);
				 
				 int countOfFiles = file.listFiles().length;
				 if (countOfFiles > 0){
					 files = new String[countOfFiles];
					 //���������� ������, �������� ����� ������ � workspace
					 files = file.list();
					 
					 for (int i=0; i<countOfFiles; i++){
						 if (files[i].charAt(files[i].length()-1) == 'd'){
							 if (files[i].charAt(files[i].length()-2) == 'p'){
								 if (files[i].charAt(files[i].length()-3) == 'c'){
									 if (files[i].charAt(files[i].length()-4) == '.'){
										 //������� ������ ����� ������� �������!
										//System.out.println(files[i]); 
										 
										 list.add(files[i]);
										 
										 System.out.println(files[i]);
									 }
								 }
							 }
						 }
					 }
				 }else{
					 //����� ����������� 
				 }
				
				
			}
		});
		button_4.setForeground(Color.WHITE);
		button_4.setBackground(Color.GRAY);
		button_4.setBounds(10, 55, 128, 33);
		panel_5.add(button_4);
		
		final JButton button_5 = new JButton("\u041F\u0430\u043F\u043A\u0430");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String foldier = "workspace\\file\\crypter\\data";
				File f = new File("");        
				String path = f.getAbsolutePath();
				
				try{
					Runtime rt = Runtime.getRuntime();
					rt.exec(new String[]{"cmd.exe","/c","explorer "+path+"\\"+foldier});
					System.out.println("cmd.exe "+" /c " + " explorer "+ path+"\\"+foldier);
				}catch(Exception e){
					textPane.setText("����������� �����!");
				}
				
			}
		});
		button_5.setForeground(Color.WHITE);
		button_5.setBackground(Color.GRAY);
		button_5.setBounds(10, 99, 128, 33);
		panel_5.add(button_5);
		
		final JButton button_6 = new JButton("\u0423\u0434\u0430\u043B\u0438\u0442\u044C");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String fileName = "";
				try{
					fileName = list.getSelectedItem().toString();
				}catch(Exception e){
					fileName = "";
				}
				System.out.println(fileName);
				if (fileName.length() < 1){
					textPane.setText("�� ������ ����!");
				}else{
					String foldier = "\\workspace\\file\\crypter\\data\\";
					File f = new File("");        
					String path = f.getAbsolutePath();
					if (fileName.length()>4){
						Runtime rt = Runtime.getRuntime();
						try{
							rt.exec(new String[]{"cmd.exe","/c","del /q "+'"'+path+foldier+fileName+'"'});
							textPane.setText("���� "+fileName+" ������� ������!");
						}catch(Exception e){
							textPane.setText("������ �������� �����!");
						}
					}else{
						textPane.setText("�� ������ ����!");
					}
				}
				
			}
		});
		button_6.setForeground(Color.WHITE);
		button_6.setBackground(Color.GRAY);
		button_6.setBounds(10, 143, 128, 33);
		panel_5.add(button_6);
		
		
		workspace.setLayout(null);
		workspace.setBounds(148, 0, 547, 372);
		contentPane.add(workspace);
		
		Panel panel = new Panel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(0, 0, 4, 372);
		workspace.add(panel);
		
		Panel panel_7 = new Panel();
		panel_7.setLayout(null);
		panel_7.setBackground(Color.DARK_GRAY);
		panel_7.setBounds(0, 0, 547, 18);
		workspace.add(panel_7);
		
		final JLabel label_2 = new JLabel("\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043E\u043A\u043D\u043E");
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("Verdana", Font.PLAIN, 11));
		label_2.setBounds(230, 0, 145, 14);
		panel_7.add(label_2);
		
		if (isLicense){
			JLabel label_5 = new JLabel("�������� �������");
			label_5.setForeground(Color.GREEN);
			label_5.setBounds(415, -1, 148, 16);
			panel_7.add(label_5);
		}else{
			JLabel label_5 = new JLabel("�������� �� �������!");
			label_5.setForeground(Color.GREEN);
			label_5.setBounds(415, -1, 148, 16);
			panel_7.add(label_5);
		}
		
		Panel panel_8 = new Panel();
		panel_8.setLayout(null);
		panel_8.setBackground(Color.LIGHT_GRAY);
		panel_8.setBounds(0, 21, 547, 351);
		workspace.add(panel_8);
		list.setFont(new Font("Verdana", Font.PLAIN, 12));
		

		list.setBackground(Color.LIGHT_GRAY);
		list.setBounds(409, 0, 138, 209);
		panel_8.add(list);
		
		
		textPane.setEditable(false);
		textPane.setBounds(12, 12, 391, 33);
		panel_8.add(textPane);
		
		Panel panel_3 = new Panel();
		panel_3.setLayout(null);
		panel_3.setBounds(409, 215, 158, 136);
		panel_8.add(panel_3);
		
		Panel panel_6 = new Panel();
		panel_6.setLayout(null);
		panel_6.setBackground(Color.DARK_GRAY);
		panel_6.setBounds(0, 0, 300, 18);
		panel_3.add(panel_6);
		
		final JLabel label_3 = new JLabel("\u0411\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u044C");
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("Verdana", Font.PLAIN, 11));
		label_3.setBounds(31, 0, 145, 14);
		panel_6.add(label_3);
		
		Panel panel_9 = new Panel();
		panel_9.setLayout(null);
		panel_9.setBackground(Color.LIGHT_GRAY);
		panel_9.setBounds(0, 21, 148, 106);
		panel_3.add(panel_9);
		
		final JButton button_7 = new JButton("\u041E\u0442\u043A\u0440\u044B\u0442\u044C");
		button_7.setBounds(12, 60, 113, 33);
		panel_9.add(button_7);
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String key_ = key.getText();
				
				boolean isValid = false;
				
				for (int i=0; i<key_.length(); i++){
					if (key_.charAt(i) >= '0' && key_.charAt(i) <= '9'){
						isValid = true;
					}else{
						isValid = false;
						break;
					}
				}
		
					if (key_.length() > 0 && key_.length() < 512){
						if (isValid){
						
						
						//System.out.println(list.getSelectedItem());
						//��������� ����
						String fileName = list.getSelectedItem();
						
						String fullPath = WorkspacePath + fileName;
						
						CRIPT cr = new CRIPT();
						try {
							cr.Decript(WorkspacePath, fileName, key_);
							textPane.setText("�������!");
							
						} catch (Exception e) {
							textPane.setText("������!");
						}
					}else{
						textPane.setText("�� ����� ���� ������!");
						
					}
				}else{
					textPane.setText("�� ������ ���� ������������ ��� �����!");
				}
				
			}
		});
		button_7.setForeground(Color.WHITE);
		button_7.setBackground(Color.GRAY);
		
		final JLabel label_4 = new JLabel("\u041A\u043B\u044E\u0447 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438");
		label_4.setBounds(12, 0, 136, 16);
		panel_9.add(label_4);
		
		key = new JTextField();
		key.setBounds(12, 28, 114, 20);
		panel_9.add(key);
		key.setColumns(10);
		
		Panel panel_10 = new Panel();
		panel_10.setLayout(null);
		panel_10.setBackground(Color.DARK_GRAY);
		panel_10.setBounds(0, 61, 410, 18);
		panel_8.add(panel_10);
		
		final JLabel label_5 = new JLabel("\u0413\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F \u043A\u043B\u044E\u0447\u0430");
		label_5.setForeground(Color.WHITE);
		label_5.setFont(new Font("Verdana", Font.PLAIN, 11));
		label_5.setBounds(159, 0, 145, 14);
		panel_10.add(label_5);
		
		final JButton button_8 = new JButton("\u0413\u0435\u043D\u0435\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				//��������� ����� 
				
				int KeyLength = 256;
				String Key = "";
				for (int i=0; i<KeyLength; i++){
					Key += String.valueOf(((int)i*System.currentTimeMillis()));
					if (Key.length() > 256){
						break;
					}
				}

				textField.setText(Key);
				
			}
		});
		button_8.setForeground(Color.WHITE);
		button_8.setBackground(Color.GRAY);
		button_8.setBounds(150, 123, 128, 33);
		panel_8.add(button_8);
		
		textField = new JTextField();
		textField.setFont(new Font("Verdana", Font.PLAIN, 12));
		textField.setBounds(12, 96, 391, 20);
		panel_8.add(textField);
		textField.setColumns(10);
		
		
		final JButton button = new JButton("\u042F\u0437\u044B\u043A");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				countOfClick++;
				for (int i=0; i<2; i++){
					if (countOfClick==1){
						label.setText("Control panel");
						label_2.setText("Workspace");
						label_1.setText("Work with data");
						button.setText("Language");
						button_1.setText("Assistent");
						button_2.setText("Other");
						button_3.setText("Add");
						button_4.setText("List");
						button_5.setText("Foldier");
						button_6.setText("Delete");
						button_7.setText("Open");
						label_4.setText("Sequrity key");
						label_3.setText("Sequrity");
						label_5.setText("Key generator");
						button_8.setText("Generate");
					}
					if (countOfClick==2){
						label.setText("������� ������");
						label_2.setText("����� ������");
						label_1.setText("����������� �����");
						button.setText("���");
						button_1.setText("�������");
						button_2.setText("�����");
						button_3.setText("����");
						button_4.setText("�����");
						button_5.setText("�����");
						button_6.setText("���");
						button_7.setText("���");
						label_4.setText("����������� �����");
						label_3.setText("�����������");
						label_5.setText("����� ���������");
						button_8.setText("������������");
						
					}
					if (countOfClick==3){
						label.setText("������ ����������");
						label_2.setText("������� ����");
						label_1.setText("������ � �������");
						button.setText("����");
						button_1.setText("��������");
						button_2.setText("������");
						button_3.setText("��������");
						button_4.setText("������");
						button_5.setText("�����");
						button_6.setText("�������");
						button_7.setText("�������");
						label_4.setText("���� ������������");
						label_3.setText("������������");
						label_5.setText("��������� �����");
						button_8.setText("������������");
					}
					if (countOfClick==4){
						countOfClick = 1;
					}
				}
				
				
				
			}
		});
		button.setBackground(Color.GRAY);
		button.setForeground(Color.WHITE);
		button.setBounds(10, 11, 128, 33);
		panel_2.add(button);
		
		
	
	}
	
	
	
	
	public static String showFileDialog(){
		File file = null;
		
		JFileChooser fileopen = new JFileChooser();
		int ret = fileopen.showDialog(null, "������� ����");                
		if (ret == JFileChooser.APPROVE_OPTION) {
		    file = fileopen.getSelectedFile();
		    return file.getAbsolutePath();
		}
		 return "0";
		
	}
	
	
	public int getValidation(){
		try{
			String licenseFile = "settings/license.lic";
		
			FileInputStream fis = new FileInputStream (licenseFile);
		
			byte[] block = new byte[8];
			String mainKey = "";
			int i;
			while( (i=fis.read(block)) != -1){
				mainKey += Character.getName(((byte)block[0]));
				mainKey += Character.getName(((byte)block[1]));
				mainKey += Character.getName(((byte)block[2]));
				mainKey += Character.getName(((byte)block[3]));
				mainKey += Character.getName(((byte)block[4]));
				mainKey += Character.getName(((byte)block[5]));
				mainKey += Character.getName(((byte)block[6]));
				mainKey += Character.getName(((byte)block[7]));
			}
			fis.close();
			if (mainKey.equals("DIGIT SEVENDIGIT TWODIGIT THREEDIGIT THREEDIGIT FIVEDIGIT SEVENLATIN CAPITAL LETTER EHYPHEN-MINUSDIGIT NINEDIGIT FIVELATIN CAPITAL LETTER CLATIN CAPITAL LETTER BDIGIT THREEDIGIT ONEHYPHEN-MINUSDIGIT TWODIGIT EIGHTDIGIT FIVEDIGIT EIGHTDIGIT ZERODIGIT FIVEDIGIT SEVENLATIN CAPITAL LETTER AHYPHEN-MINUSDIGIT ONELATIN CAPITAL LETTER BLATIN CAPITAL LETTER FLATIN CAPITAL LETTER ALATIN CAPITAL LETTER BLATIN CAPITAL LETTER BLATIN CAPITAL LETTER CDIGIT THREEHYPHEN-MINUSDIGIT TWOLATIN CAPITAL LETTER CLATIN CAPITAL LETTER BDIGIT EIGHTLATIN CAPITAL LETTER FLATIN CAPITAL LETTER ADIGIT FOURDIGIT NINEHYPHEN-MINUSDIGIT TWOLATIN CAPITAL LETTER ADIGIT FIVEDIGIT SIXDIGIT ONEDIGIT ONEDIGIT ONEDIGIT SIXHYPHEN-MINUSDIGIT ONEDIGIT FOURDIGIT TWOLATIN CAPITAL LETTER CDIGIT ZERODIGIT NINELATIN CAPITAL LETTER ADIGIT NINEHYPHEN-MINUSLATIN CAPITAL LETTER DLATIN CAPITAL LETTER ADIGIT TWOLATIN CAPITAL LETTER ADIGIT FIVELATIN CAPITAL LETTER FLATIN CAPITAL LETTER CHYPHEN-MINUSLATIN CAPITAL LETTER DLATIN CAPITAL LETTER ADIGIT TWOLATIN CAPITAL LETTER A")){
				return 1;
			}else{
				return 0;
			}
		}catch(Exception e){
			return 2;
		}
	}
}
